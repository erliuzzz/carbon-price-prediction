%% 主函数调用样本熵函数求时间序列的样本熵值
clear all;
clc;
rng(123)
fs=200;  %采样频率
t = 1/fs:1/fs:1;  %时间轴数据
X = 1*cos(2*pi*200*t)+(2*randn(size(t)));  %生成仿真数据
[m,~]=size(X);  % X为时间序列,一行为一个时间序列。
% 求样本熵:pe为排列熵
dim=2;% 嵌入维数
r0=0.2;
r=r0*std(X);
tau=1;
sampEn = SampleEntropy( dim, r, X, tau );

