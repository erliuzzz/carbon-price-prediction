clc; clear; close all;

% 读取xlsx文件中的日期和信号数据
filename = 'test2.xlsx'; % 你的文件名
sheet = 1; % 假设数据在第一个工作表

% 读取第一列日期和第二列信号数据
[dateData, ~, ~] = xlsread(filename, sheet, 'A:A'); % 读取第一列日期
[sigData, ~, ~] = xlsread(filename, sheet, 'B:B'); % 读取第二列信号数据

% 转换第一列日期为日期时间数组
% 假设第一列中的日期格式为 'mm/dd/yyyy'
dates = datenum(dateData, 'mm/dd/yyyy');

% 计算时间向量
t = (dates - dates(1)) / (24 * 60 * 60); % 将日期转换为相对于第一个日期的时间秒数

% 以下代码为信号处理部分...
% 假设SNR, rng, sig等变量和函数已经定义和初始化
SNR = 5; rng(10);
sig = awgn(sig, SNR, 'measured');

% 绘制原始信号和频谱图
figure('Name', '原始信号');
subplot(211); plot(t, sig, 'k'); title('原始信号');
ylabel('幅值'); xlabel('Time/s');

subplot(212); pFFT(sig, Fs); title('频谱图');
ylabel('幅值'); xlabel('Frequency/Hz');

% 以下代码为EMD分解和样本熵计算部分...
Nstd = 0.02; NE = 100; MaxIter = 1000;
[IMF] = iceemdan(sig, Nstd, NE, MaxIter, 1); % 调用函数

% 假设CEEMDAN_IMF1和CEEMDAN_IMF2是ICEEMDAN分解后的两个IMF
% 你需要根据实际情况来获取这些IMF，这里只是一个示例
name = 'ICEEMDAN分解';
[CEEMDAN_IMF1] = Huatu(name, IMF, sig, t);
name = 'ICEEMDAN分解';
[CEEMDAN_IMF2] = Huatu(name, IMF, sig, t, Fs);

% 计算样本熵
sampEn = zeros(size(CEEMDAN_IMF1, 1), 1);
dim = 2;
r0 = 0.2;
r = r0 * std(CEEMDAN_IMF1(:, 1));
tau = 1;
for i = 1:size(CEEMDAN_IMF1, 1)
    sampEn(i) = SampleEntropy(dim, r, CEEMDAN_IMF1(:, i), tau);
end

% 绘制样本熵
figure;
plot(sampEn, '-o');
xlabel('分解所得序列'); ylabel('序列样本熵值');



