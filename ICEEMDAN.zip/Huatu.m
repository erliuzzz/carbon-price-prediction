function [IMF]=Huatu(Name,imf,signal,t,Fs)
[nRows, nCols] = size(imf);
if nRows > nCols
    IMF = imf.';  % 转置操作
else
    IMF = imf;
end
if nargin <5
figure('Name','模态分解与各IMF分量时域图','Color','white');
set(gcf, 'Position', [400 100 600 700]);
subplot(size(IMF,1)+1,1,1);
plot(t,signal,'k');grid on;
ylabel('原始数据');
title(Name);
set(gca,'XTick',[]);
for i = 2:size(IMF,1)+1
    subplot(size(IMF,1)+1,1,i);
    plot(t,IMF(i-1,:),'k');
    ylabel(['\fontname{Times new roman}IMF',num2str(i-1)]);
    if (i ~= size(IMF,1)+1)
        set(gca,'XTick',[]);
    end
    if (i == size(IMF,1)+1)
        ylabel('\fontname{Times new roman}RSE');
        xlabel('\fontname{Times new roman}Time/\it{s}');
    end
    grid on;
end
else
figure('Name','模态分解与各IMF分量频谱对照图','Color','white');set(gcf, 'Position', [400 100 600 700]);
subplot(size(IMF,1)+1,2,1);
plot(t,signal,'k');grid on;
ylabel('原始数据');
title(Name);
set(gca,'XTick',[]);
subplot(size(IMF,1)+1,2,2);
pFFT(signal,Fs);grid on;
title('\fontname{宋体}对应频谱');
set(gca,'XTick',[]);
for i = 2:size(IMF,1)+1
    subplot(size(IMF,1)+1,2,i*2-1);
    plot(t,IMF(i-1,:),'k');
    ylabel(['\fontname{Times new roman}IMF',num2str(i-1)]);
    if (i ~= size(IMF,1)+1)
        set(gca,'XTick',[]);
    end
    if (i == size(IMF,1)+1)
        ylabel('\fontname{Times new roman}RSE');
        xlabel('\fontname{Times new roman}Time/\it{s}');
    end
    grid on;
    subplot(size(IMF,1)+1,2,i*2);
    pFFT(IMF(i-1,:),Fs);
    if (i ~= size(IMF,1)+1)
        set(gca,'XTick',[]);
    end
    if (i == size(IMF,1)+1)
        xlabel('\fontname{Times new roman}Frequency/\it{Hz}');
    end
    grid on;
end
end